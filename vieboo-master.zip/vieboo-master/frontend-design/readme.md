### header & footer
* header.html
* footer.html


### friendship
* friendship-following.html
* friendship-followed.html
* friendship-mutually.html
* friendship-blocking.html


### chatting
* chatting-new.html
* chatting-inbox.html
* chatting-outbox.html
